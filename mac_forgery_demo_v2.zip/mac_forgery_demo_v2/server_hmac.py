# server_hmac.py – Secure server using HMAC

import hmac
import hashlib

SECRET_KEY = b'supersecretkey'  # Secret key (same as before)

def generate_mac(message: bytes) -> str:
    return hmac.new(SECRET_KEY, message, hashlib.md5).hexdigest()

def verify(message: bytes, mac: str) -> bool:
    expected_mac = generate_mac(message)
    return hmac.compare_digest(mac, expected_mac)

def main():
    message = b"amount=100&to=alice"
    mac = generate_mac(message)

    print("=== Secure Server (HMAC) ===")
    print(f"Original message: {message.decode()}")
    print(f"MAC: {mac}")
    print("\n--- Verifying legitimate message ---")
    if verify(message, mac):
        print("MAC verified successfully. Message is authentic.\n")

    # Try verifying attacker-forged message
    try:
        with open("forged_data.txt", "r") as f:
            forged_message = f.readline().strip().encode()
            forged_mac = f.readline().strip()
            print("--- Verifying attacker forged message ---")
            if verify(forged_message, forged_mac):
                print("MAC verified successfully (UNEXPECTED - ATTACK SUCCEEDED?)")
            else:
                print("MAC verification failed (attack blocked ✅)")
    except FileNotFoundError:
        print("No forged_data.txt found. Skipping forged verification.")

if __name__ == "__main__":
    main()
