import hashpumpy

# Intercepted data from server
original_msg = b"amount=100&to=alice"
original_mac = "614d28d808af46d3702fe35fae67267c"  # paste the MAC from server.py here
append_data = b"&admin=true"
key_length = 14  # Length of the secret key used on server

# Perform length extension attack
new_mac, new_message = hashpumpy.hashpump(
    original_mac, original_msg.decode(), append_data.decode(), key_length
)

# Save the forged message and MAC
with open("forged_data.txt", "w") as f:
    f.write(f"{new_message}\n{new_mac}")

# Print them to screen
print("[+] Forged message:", new_message.decode(errors="ignore"))
print("[+] Forged MAC:", new_mac)
